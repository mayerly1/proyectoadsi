-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 08-06-2016 a las 01:12:22
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `sale`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `app_config`
-- 

CREATE TABLE `app_config` (
  `key` varchar(300) collate utf8_unicode_ci NOT NULL,
  `value` varchar(300) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Volcar la base de datos para la tabla `app_config`
-- 

INSERT INTO `app_config` VALUES ('address', 'Dirección: Calle 36 # 3 B 81 sur');
INSERT INTO `app_config` VALUES ('company', 'Sistema de Ventas Pintuedward NIT:830.227.885-3');
INSERT INTO `app_config` VALUES ('currency_symbol', '$ ');
INSERT INTO `app_config` VALUES ('default_tax_1_name', 'IVA');
INSERT INTO `app_config` VALUES ('default_tax_1_rate', '16');
INSERT INTO `app_config` VALUES ('default_tax_2_name', 'Impuesto de Ventas 2');
INSERT INTO `app_config` VALUES ('default_tax_2_rate', '');
INSERT INTO `app_config` VALUES ('default_tax_rate', '8');
INSERT INTO `app_config` VALUES ('email', 'pintuedward@gmail.com');
INSERT INTO `app_config` VALUES ('fax', '');
INSERT INTO `app_config` VALUES ('phone', 'Teléfono: 4520618');
INSERT INTO `app_config` VALUES ('print_after_sale', 'print_after_sale');
INSERT INTO `app_config` VALUES ('return_policy', 'Test');
INSERT INTO `app_config` VALUES ('timezone', 'America/Bogota');
INSERT INTO `app_config` VALUES ('website', '');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `customers`
-- 

CREATE TABLE `customers` (
  `person_id` int(11) NOT NULL,
  `taxable` int(1) NOT NULL default '1',
  `deleted` int(1) NOT NULL default '0',
  KEY `person_id` (`person_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Volcar la base de datos para la tabla `customers`
-- 

INSERT INTO `customers` VALUES (2, 1, 0);
INSERT INTO `customers` VALUES (3, 1, 0);
INSERT INTO `customers` VALUES (7, 1, 0);
INSERT INTO `customers` VALUES (9, 1, 0);
INSERT INTO `customers` VALUES (10, 1, 0);
INSERT INTO `customers` VALUES (13, 1, 0);
INSERT INTO `customers` VALUES (15, 1, 0);
INSERT INTO `customers` VALUES (17, 1, 0);
INSERT INTO `customers` VALUES (22, 1, 0);
INSERT INTO `customers` VALUES (23, 1, 1);
INSERT INTO `customers` VALUES (25, 1, 0);
INSERT INTO `customers` VALUES (26, 1, 0);
INSERT INTO `customers` VALUES (27, 1, 0);
INSERT INTO `customers` VALUES (33, 1, 0);
INSERT INTO `customers` VALUES (34, 1, 0);
INSERT INTO `customers` VALUES (35, 1, 0);
INSERT INTO `customers` VALUES (36, 1, 0);
INSERT INTO `customers` VALUES (37, 1, 1);
INSERT INTO `customers` VALUES (38, 1, 0);
INSERT INTO `customers` VALUES (40, 1, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `employees`
-- 

CREATE TABLE `employees` (
  `username` varchar(300) collate utf8_unicode_ci NOT NULL,
  `password` varchar(300) collate utf8_unicode_ci NOT NULL,
  `person_id` int(11) NOT NULL,
  `deleted` int(1) NOT NULL default '0',
  UNIQUE KEY `username` (`username`),
  KEY `person_id` (`person_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Volcar la base de datos para la tabla `employees`
-- 

INSERT INTO `employees` VALUES ('admin', '987123456', 1, 0);
INSERT INTO `employees` VALUES ('caravill', '123456789', 14, 0);
INSERT INTO `employees` VALUES ('lmesi', 'c4fbb197bc512be66a6d1de2e04c79cd', 5, 0);
INSERT INTO `employees` VALUES ('almacen', '123456789', 6, 0);
INSERT INTO `employees` VALUES ('vendedor', '123456987', 24, 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `inventory`
-- 

CREATE TABLE `inventory` (
  `trans_id` int(11) NOT NULL auto_increment,
  `trans_items` int(11) NOT NULL default '0',
  `trans_user` int(11) NOT NULL default '0',
  `trans_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `trans_comment` text collate utf8_unicode_ci NOT NULL,
  `trans_inventory` int(11) NOT NULL default '0',
  PRIMARY KEY  (`trans_id`),
  KEY `inventory_ibfk_1` (`trans_items`),
  KEY `inventory_ibfk_2` (`trans_user`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=47 ;

-- 
-- Volcar la base de datos para la tabla `inventory`
-- 

INSERT INTO `inventory` VALUES (1, 5, 1, '2016-02-18 00:17:12', 'RECV 1', 1);
INSERT INTO `inventory` VALUES (2, 5, 1, '2016-02-18 00:46:59', 'RECV 2', 10);
INSERT INTO `inventory` VALUES (3, 4, 1, '2016-02-23 19:50:14', 'FRA. 3', -3);
INSERT INTO `inventory` VALUES (4, 3, 1, '2016-02-23 19:50:15', 'FRA. 3', -2);
INSERT INTO `inventory` VALUES (5, 4, 1, '2016-04-06 18:20:15', 'FRA. 4', -1);
INSERT INTO `inventory` VALUES (6, 3, 1, '2016-04-06 18:20:16', 'FRA. 4', -5);
INSERT INTO `inventory` VALUES (7, 5, 1, '2016-05-06 09:13:41', 'FRA. 5', -5);
INSERT INTO `inventory` VALUES (8, 3, 1, '2016-05-06 09:15:14', 'FRA. 6', -3);
INSERT INTO `inventory` VALUES (9, 5, 1, '2016-05-06 09:15:14', 'FRA. 6', -1);
INSERT INTO `inventory` VALUES (10, 5, 1, '2016-05-06 09:53:11', 'FRA. 7', -2);
INSERT INTO `inventory` VALUES (11, 2, 1, '2016-05-10 10:22:05', 'FRA. 8', -3);
INSERT INTO `inventory` VALUES (12, 1, 1, '2016-05-10 10:23:27', 'FRA. 9', -3);
INSERT INTO `inventory` VALUES (13, 1, 24, '2016-05-10 10:37:51', 'FRA. 10', -3);
INSERT INTO `inventory` VALUES (14, 3, 1, '2016-05-11 07:48:08', 'FRA. 11', -3);
INSERT INTO `inventory` VALUES (15, 2, 1, '2016-05-11 07:48:08', 'FRA. 11', -5);
INSERT INTO `inventory` VALUES (16, 3, 1, '2016-05-11 07:58:09', 'FRA. 12', -5);
INSERT INTO `inventory` VALUES (17, 1, 1, '2016-05-11 07:58:48', 'RECV 3', 10);
INSERT INTO `inventory` VALUES (18, 2, 1, '2016-05-11 07:59:28', 'RECV 4', 30);
INSERT INTO `inventory` VALUES (19, 2, 1, '2016-05-11 08:37:44', 'FRA. 13', -2);
INSERT INTO `inventory` VALUES (20, 3, 1, '2016-05-12 08:02:56', '', 500);
INSERT INTO `inventory` VALUES (21, 3, 1, '2016-05-12 08:03:11', '', 1000);
INSERT INTO `inventory` VALUES (22, 3, 1, '2016-05-12 09:48:37', 'FRA. 14', -1);
INSERT INTO `inventory` VALUES (23, 3, 1, '2016-05-17 09:40:37', 'FRA. 15', -3);
INSERT INTO `inventory` VALUES (24, 1, 1, '2016-05-17 09:44:19', 'FRA. 16', -1);
INSERT INTO `inventory` VALUES (25, 1, 1, '2016-05-17 10:37:32', 'FRA. 17', 1);
INSERT INTO `inventory` VALUES (26, 2, 1, '2016-05-17 10:42:02', 'FRA. 18', -1);
INSERT INTO `inventory` VALUES (27, 2, 1, '2016-05-17 10:42:53', 'FRA. 19', 1);
INSERT INTO `inventory` VALUES (28, 4, 1, '2016-05-17 10:49:21', 'Edición Manual de Cantidad', 100);
INSERT INTO `inventory` VALUES (29, 4, 1, '2016-05-17 10:51:46', 'FRA. 20', -1);
INSERT INTO `inventory` VALUES (30, 4, 1, '2016-05-20 06:47:13', 'FRA. 21', -3);
INSERT INTO `inventory` VALUES (31, 2, 1, '2016-05-20 07:00:22', 'FRA. 22', -1);
INSERT INTO `inventory` VALUES (32, 3, 1, '2016-05-20 07:03:48', 'FRA. 23', -1);
INSERT INTO `inventory` VALUES (33, 2, 1, '2016-05-20 07:03:48', 'FRA. 23', -1);
INSERT INTO `inventory` VALUES (34, 2, 1, '2016-05-20 07:21:55', 'FRA. 24', -4);
INSERT INTO `inventory` VALUES (35, 3, 1, '2016-05-20 07:23:46', 'FRA. 25', -2);
INSERT INTO `inventory` VALUES (36, 3, 1, '2016-05-20 09:26:59', 'FRA. 26', -2);
INSERT INTO `inventory` VALUES (37, 2, 1, '2016-05-20 09:28:01', 'FRA. 27', -3);
INSERT INTO `inventory` VALUES (38, 4, 1, '2016-05-31 10:11:27', '', 5);
INSERT INTO `inventory` VALUES (39, 5, 1, '2016-05-31 11:41:48', 'Edición Manual de Cantidad', 1);
INSERT INTO `inventory` VALUES (40, 3, 1, '2016-05-31 11:43:48', 'FRA. 28', -4);
INSERT INTO `inventory` VALUES (41, 5, 1, '2016-05-31 20:04:04', 'RECV 5', 50);
INSERT INTO `inventory` VALUES (42, 2, 1, '2016-05-31 20:10:19', 'FRA. 29', -1);
INSERT INTO `inventory` VALUES (43, 5, 1, '2016-05-31 20:48:09', 'FRA. 30', -2);
INSERT INTO `inventory` VALUES (44, 3, 1, '2016-05-31 20:50:48', 'FRA. 31', -1);
INSERT INTO `inventory` VALUES (45, 4, 1, '2016-06-07 23:33:08', 'FRA. 32', -3);
INSERT INTO `inventory` VALUES (46, 3, 1, '2016-06-08 00:05:47', 'RECV 6', 2);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `items`
-- 

CREATE TABLE `items` (
  `name` varchar(300) collate utf8_unicode_ci NOT NULL,
  `category` varchar(300) collate utf8_unicode_ci NOT NULL,
  `supplier_id` int(11) default NULL,
  `item_number` varchar(300) collate utf8_unicode_ci default NULL,
  `description` varchar(300) collate utf8_unicode_ci NOT NULL,
  `cost_price` double(15,2) NOT NULL,
  `unit_price` double(15,2) NOT NULL,
  `quantity` double(15,2) NOT NULL default '0.00',
  `item_id` int(11) NOT NULL auto_increment,
  `deleted` int(1) NOT NULL default '0',
  PRIMARY KEY  (`item_id`),
  UNIQUE KEY `item_number` (`item_number`),
  KEY `items_ibfk_1` (`supplier_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

-- 
-- Volcar la base de datos para la tabla `items`
-- 

INSERT INTO `items` VALUES ('Pintura Blanca', 'Vinilos', 4, '0182456641', 'caneca de pintura por 5 galones', 103230.00, 135000.00, 28.00, 1, 0);
INSERT INTO `items` VALUES ('laca negra', 'Lacas', 4, '0183875796', '', 31000.00, 35000.00, 19.00, 2, 0);
INSERT INTO `items` VALUES ('Esmalte blanco ', 'Esmaltes', 11, '01248751363', 'Esmalte superlavable 5 galones', 150000.00, 180000.00, 1533.00, 3, 0);
INSERT INTO `items` VALUES ('Esmalte Negro', 'Esmaltes', 4, '0124522222', 'Pintura Lavable negra', 145000.00, 178000.00, 98.00, 4, 0);
INSERT INTO `items` VALUES ('laca caoba', 'Lacas', 18, '1255545622', '', 35000.00, 41000.00, 49.00, 5, 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `items_taxes`
-- 

CREATE TABLE `items_taxes` (
  `item_id` int(11) NOT NULL,
  `name` varchar(300) collate utf8_unicode_ci NOT NULL,
  `percent` double(15,2) NOT NULL,
  PRIMARY KEY  (`item_id`,`name`,`percent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Volcar la base de datos para la tabla `items_taxes`
-- 

INSERT INTO `items_taxes` VALUES (1, 'IVA', 16.00);
INSERT INTO `items_taxes` VALUES (2, 'IVA', 16.00);
INSERT INTO `items_taxes` VALUES (3, 'IVA', 16.00);
INSERT INTO `items_taxes` VALUES (4, 'IVA', 16.00);
INSERT INTO `items_taxes` VALUES (5, 'IVA', 16.00);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `modules`
-- 

CREATE TABLE `modules` (
  `name_lang_key` varchar(300) collate utf8_unicode_ci NOT NULL,
  `desc_lang_key` varchar(300) collate utf8_unicode_ci NOT NULL,
  `sort` int(11) NOT NULL,
  `module_id` varchar(300) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`module_id`),
  UNIQUE KEY `desc_lang_key` (`desc_lang_key`),
  UNIQUE KEY `name_lang_key` (`name_lang_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Volcar la base de datos para la tabla `modules`
-- 

INSERT INTO `modules` VALUES ('module_config', 'module_config_desc', 100, 'config');
INSERT INTO `modules` VALUES ('module_customers', 'module_customers_desc', 10, 'customers');
INSERT INTO `modules` VALUES ('module_employees', 'module_employees_desc', 80, 'employees');
INSERT INTO `modules` VALUES ('module_items', 'module_items_desc', 20, 'items');
INSERT INTO `modules` VALUES ('module_receivings', 'module_receivings_desc', 60, 'receivings');
INSERT INTO `modules` VALUES ('module_reports', 'module_reports_desc', 50, 'reports');
INSERT INTO `modules` VALUES ('module_sales', 'module_sales_desc', 70, 'sales');
INSERT INTO `modules` VALUES ('module_suppliers', 'module_suppliers_desc', 40, 'suppliers');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `people`
-- 

CREATE TABLE `people` (
  `first_name` varchar(300) collate utf8_unicode_ci NOT NULL,
  `last_name` varchar(300) collate utf8_unicode_ci NOT NULL,
  `documento` bigint(11) NOT NULL,
  `phone_number` varchar(300) collate utf8_unicode_ci NOT NULL,
  `email` varchar(300) collate utf8_unicode_ci NOT NULL,
  `address_1` varchar(300) collate utf8_unicode_ci NOT NULL,
  `city` varchar(300) collate utf8_unicode_ci NOT NULL,
  `state` varchar(300) collate utf8_unicode_ci NOT NULL,
  `country` varchar(300) collate utf8_unicode_ci NOT NULL,
  `comments` text collate utf8_unicode_ci NOT NULL,
  `person_id` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`person_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=41 ;

-- 
-- Volcar la base de datos para la tabla `people`
-- 

INSERT INTO `people` VALUES ('Yaneth', 'Castro', 52626358, '4596823', 'Yane.cast@gmail.com', 'Calles 147', '', '', '', '', 1);
INSERT INTO `people` VALUES ('Francisco', 'Memdez', 19568245, '', 'francisco.mendez@gmail.com', '', '', '', '', '', 2);
INSERT INTO `people` VALUES ('Nadin', 'Heredia', 52364221, '304825409', 'nadine@gmail.com', '', '', '', '', '', 3);
INSERT INTO `people` VALUES ('Luis ', 'Diaz', 8005302563, '', '', '', '', '', '', '', 4);
INSERT INTO `people` VALUES ('Leonel', 'Mezi', 25987452, '', 'lenoel.mezi@gmail.com', '', '', '', '', '', 5);
INSERT INTO `people` VALUES ('Mayerly', 'Rojas', 1030258975, '3212425242', '', '', '', '', '', '', 6);
INSERT INTO `people` VALUES ('Damaris', 'Lopez', 52457898, '3202587488', '', '', '', '', '', '', 7);
INSERT INTO `people` VALUES ('Marcos Andres', 'Contrera Bedoya', 79668351, '3182548364', 'contbedoymar@gmail.com', 'Cra 8 # 52-12 s', 'Bogota', 'null', 'Colombia', '', 8);
INSERT INTO `people` VALUES ('raul', 'diaz', 79584575, '', 'rauldiaz@gmail.com', '', '', '', '', '', 9);
INSERT INTO `people` VALUES ('Marcos', 'Ramirez', 1030258963, '', 'marcramir@gmail.com', '', '', '', '', '', 10);
INSERT INTO `people` VALUES ('Maria', 'Reyes', 830120580, '', 'pintuco@pintuco.com.co', '', '', '', '', '', 11);
INSERT INTO `people` VALUES ('Elsa', 'Rojas', 9308502154, '3102987584', 'Pintduitama@hotmail.com', '', 'duitama', 'boyaca', '', '', 12);
INSERT INTO `people` VALUES ('Jaime ', 'Rueda', 80536985, '3112254854', '', '', '', '', '', '', 13);
INSERT INTO `people` VALUES ('Carlos', 'Arias', 1030258459, '3215421512', 'caravill@gmail.com', '', '', '', 'Colombia', '', 14);
INSERT INTO `people` VALUES ('Luz Marina', 'Carvajal', 1030569882, '4258792', '', '', '', '', '', '', 15);
INSERT INTO `people` VALUES ('Fabian', 'Ramirez', 80584575, '', '', '', '', '', '', '', 17);
INSERT INTO `people` VALUES ('Javier ', 'Fernandez', 8305302563, '', '', '', '', '', '', '', 18);
INSERT INTO `people` VALUES ('martin a', 'carrillo', 1030258458, '', '', '', '', '', '', '', 22);
INSERT INTO `people` VALUES ('frhrdjh', 'srfhdrj', 1030258450, '', '', '', '', '', '', '', 23);
INSERT INTO `people` VALUES ('Melisa', 'Valencia', 1025424212, '', 'melval@gmail.com', '', '', '', '', '', 24);
INSERT INTO `people` VALUES ('dddd', 'ddddd', 122, '', '', '', '', '', '', '', 25);
INSERT INTO `people` VALUES ('dqario', 'dddd', 1235, '', '', '', '', '', '', '', 26);
INSERT INTO `people` VALUES ('fvsfdfgvsdg', 'fsfsgf', 122, '', '', '', '', '', '', '', 27);
INSERT INTO `people` VALUES ('gdgedgdg', 'gdgdg', 12545, '', '', '', '', '', '', '', 28);
INSERT INTO `people` VALUES ('rdthrdtjtgj', 'rsjtdktjtdj', 68235, '', '', '', '', '', '', '', 29);
INSERT INTO `people` VALUES ('sabgsdb', 'dbhhedbhdb', 68235, '', '', '', '', '', '', '', 30);
INSERT INTO `people` VALUES ('grdhttjh', 'ethrjtdrjhtdj', 8005302563, '', '', '', '', '', '', '', 31);
INSERT INTO `people` VALUES ('wgegeg', 'gesrtgrh', 545222, '', '', '', '', '', '', '', 32);
INSERT INTO `people` VALUES ('wgehgerhr', 'ehgrejthrtdhr', 5245652, '', '', '', '', '', '', '', 33);
INSERT INTO `people` VALUES ('sgvdsgdsrh', 'esrhdfthdth', 2452, '', '', '', '', '', '', '', 34);
INSERT INTO `people` VALUES ('bdhbdbdb', 'sgdhdrh', 11222, '', '', '', '', '', '', '', 35);
INSERT INTO `people` VALUES ('wsrfgeasgr', 'rgerrgseg', 0, '', '', '', '', '', '', '', 36);
INSERT INTO `people` VALUES ('fsfsf', 'santos', 1233, '', '', '', '', '', '', '', 37);
INSERT INTO `people` VALUES ('sgdgdg', 'dzgsdrh', 1452585, '', '', '', '', '', '', '', 38);
INSERT INTO `people` VALUES ('sagdeg', 'gdehdrhrdhrdhh', 12345666, '', '', '', '', '', '', '', 39);
INSERT INTO `people` VALUES ('getetgg', 'gdegegd', 12354582211111, '', '', '', '', '', '', '', 40);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `permissions`
-- 

CREATE TABLE `permissions` (
  `module_id` varchar(300) collate utf8_unicode_ci NOT NULL,
  `person_id` int(11) NOT NULL,
  PRIMARY KEY  (`module_id`,`person_id`),
  KEY `person_id` (`person_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Volcar la base de datos para la tabla `permissions`
-- 

INSERT INTO `permissions` VALUES ('config', 1);
INSERT INTO `permissions` VALUES ('customers', 1);
INSERT INTO `permissions` VALUES ('customers', 24);
INSERT INTO `permissions` VALUES ('employees', 1);
INSERT INTO `permissions` VALUES ('items', 1);
INSERT INTO `permissions` VALUES ('items', 5);
INSERT INTO `permissions` VALUES ('items', 6);
INSERT INTO `permissions` VALUES ('items', 14);
INSERT INTO `permissions` VALUES ('items', 24);
INSERT INTO `permissions` VALUES ('receivings', 1);
INSERT INTO `permissions` VALUES ('receivings', 6);
INSERT INTO `permissions` VALUES ('reports', 1);
INSERT INTO `permissions` VALUES ('sales', 1);
INSERT INTO `permissions` VALUES ('sales', 5);
INSERT INTO `permissions` VALUES ('sales', 24);
INSERT INTO `permissions` VALUES ('suppliers', 1);
INSERT INTO `permissions` VALUES ('suppliers', 6);
INSERT INTO `permissions` VALUES ('suppliers', 24);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `receivings`
-- 

CREATE TABLE `receivings` (
  `receiving_time` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `supplier_id` int(11) default NULL,
  `employee_id` int(11) NOT NULL default '0',
  `comment` text collate utf8_unicode_ci NOT NULL,
  `receiving_id` int(11) NOT NULL auto_increment,
  `payment_type` varchar(20) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`receiving_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

-- 
-- Volcar la base de datos para la tabla `receivings`
-- 

INSERT INTO `receivings` VALUES ('2016-02-18 00:17:12', 11, 1, '', 1, 'Efectivo');
INSERT INTO `receivings` VALUES ('2016-02-18 00:46:59', 11, 1, '', 2, 'Efectivo');
INSERT INTO `receivings` VALUES ('2016-05-11 07:58:48', 12, 1, '', 3, 'Efectivo');
INSERT INTO `receivings` VALUES ('2016-05-11 07:59:28', NULL, 1, '', 4, 'Efectivo');
INSERT INTO `receivings` VALUES ('2016-05-31 20:04:04', 4, 1, '', 5, 'Efectivo');
INSERT INTO `receivings` VALUES ('2016-06-08 00:05:47', 30, 1, '', 6, 'Efectivo');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `receivings_items`
-- 

CREATE TABLE `receivings_items` (
  `receiving_id` int(11) NOT NULL default '0',
  `item_id` int(11) NOT NULL default '0',
  `description` varchar(30) collate utf8_unicode_ci default NULL,
  `line` int(3) NOT NULL,
  `quantity_purchased` int(11) NOT NULL default '0',
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` double(15,2) NOT NULL,
  `discount_percent` int(11) NOT NULL default '0',
  PRIMARY KEY  (`receiving_id`,`item_id`,`line`),
  KEY `item_id` (`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Volcar la base de datos para la tabla `receivings_items`
-- 

INSERT INTO `receivings_items` VALUES (1, 5, 'Esmalte superlavable 5 galones', 1, 1, 150000.00, 150000.00, 0);
INSERT INTO `receivings_items` VALUES (2, 5, 'Esmalte superlavable 5 galones', 1, 10, 150000.00, 150000.00, 0);
INSERT INTO `receivings_items` VALUES (3, 1, 'caneca de pintura por 5 galone', 1, 10, 103230.00, 103230.00, 0);
INSERT INTO `receivings_items` VALUES (4, 2, '', 1, 30, 31000.00, 31000.00, 0);
INSERT INTO `receivings_items` VALUES (5, 5, '', 1, 50, 35000.00, 35000.00, 0);
INSERT INTO `receivings_items` VALUES (6, 3, 'Esmalte superlavable 5 galones', 1, 2, 150000.00, 150000.00, 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `sales`
-- 

CREATE TABLE `sales` (
  `sale_time` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `customer_id` int(11) default NULL,
  `employee_id` int(11) NOT NULL default '0',
  `comment` text collate utf8_unicode_ci,
  `sale_id` int(11) NOT NULL auto_increment,
  `payment_type` varchar(512) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`sale_id`),
  KEY `customer_id` (`customer_id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=33 ;

-- 
-- Volcar la base de datos para la tabla `sales`
-- 

INSERT INTO `sales` VALUES ('2016-02-16 21:48:58', 7, 1, '0', 1, 'Efectivo: $ 156600.00<br />');
INSERT INTO `sales` VALUES ('2016-02-17 23:31:44', 9, 1, '0', 2, 'Cheque: $ 243600.00<br />');
INSERT INTO `sales` VALUES ('2016-02-23 19:50:14', 9, 1, '0', 3, 'Tarjeta de DÃ©bito: $ 435000.00<br />');
INSERT INTO `sales` VALUES ('2016-04-06 18:20:15', 3, 1, '0', 4, 'Tarjeta de DÃ©bito: $ 823600.00<br />');
INSERT INTO `sales` VALUES ('2016-05-06 09:13:41', 7, 1, '0', 5, 'Efectivo: $ 1044000.00<br />');
INSERT INTO `sales` VALUES ('2016-05-06 09:15:14', 13, 1, '0', 6, 'Tarjeta de DÃ©bito: $ 678600.00<br />');
INSERT INTO `sales` VALUES ('2016-05-06 09:53:11', 15, 1, '0', 7, 'Efectivo: $ 417600.00<br />');
INSERT INTO `sales` VALUES ('2016-05-10 10:22:05', 15, 1, '0', 8, 'Efectivo: $ 119364.00<br />');
INSERT INTO `sales` VALUES ('2016-05-10 10:23:27', 22, 1, '0', 9, 'Efectivo: $ 469800.00<br />');
INSERT INTO `sales` VALUES ('2016-05-10 10:37:51', 13, 24, '0', 10, 'Efectivo: $ 469800.00<br />');
INSERT INTO `sales` VALUES ('2016-05-11 07:48:07', 9, 1, '0', 11, 'Tarjeta de Débito: $ 829400.00<br />');
INSERT INTO `sales` VALUES ('2016-05-11 07:58:09', 7, 1, '0', 12, 'Efectivo: $ 1044000.00<br />');
INSERT INTO `sales` VALUES ('2016-05-11 08:37:44', NULL, 1, '0', 13, 'Efectivo: $ 81200.00<br />');
INSERT INTO `sales` VALUES ('2016-05-12 09:48:37', 13, 1, '0', 14, 'Efectivo: $ 208800.00<br />');
INSERT INTO `sales` VALUES ('2016-05-17 09:40:37', NULL, 1, '0', 15, 'Efectivo: $ 626400.00<br />');
INSERT INTO `sales` VALUES ('2016-05-17 09:44:19', 15, 1, '0', 16, 'Efectivo: $ 156600.00<br />');
INSERT INTO `sales` VALUES ('2016-05-17 10:37:32', 15, 1, 'se anula FRA. 22', 17, 'Efectivo: -$ 156600.00<br />');
INSERT INTO `sales` VALUES ('2016-05-17 10:42:02', 9, 1, '0', 18, 'Efectivo: $ 40600.00<br />');
INSERT INTO `sales` VALUES ('2016-05-17 10:42:53', 9, 1, '0', 19, 'Efectivo: -$ 40600.00<br />');
INSERT INTO `sales` VALUES ('2016-05-17 10:51:46', 9, 1, '0', 20, 'Efectivo: $ 100000.00<br />Tarjeta de Débito: $ 106480.00<br />');
INSERT INTO `sales` VALUES ('2016-05-20 06:47:13', 9, 1, '0', 21, 'Efectivo: $ 619440.00<br />');
INSERT INTO `sales` VALUES ('2016-05-20 07:00:22', 9, 1, '0', 22, 'Efectivo: $ 40600.00<br />');
INSERT INTO `sales` VALUES ('2016-05-20 07:03:48', 13, 1, '0', 23, 'Efectivo: $ 249400.00<br />');
INSERT INTO `sales` VALUES ('2016-05-20 07:21:55', 22, 1, '0', 24, 'Tarjeta de Débito: $ 100000.00<br />Efectivo: $ 62400.00<br />');
INSERT INTO `sales` VALUES ('2016-05-20 07:23:46', 9, 1, '0', 25, 'Efectivo: $ 417600.00<br />');
INSERT INTO `sales` VALUES ('2016-05-20 09:26:59', NULL, 1, '0', 26, 'Efectivo: $ 417600.00<br />');
INSERT INTO `sales` VALUES ('2016-05-20 09:28:01', 15, 1, '0', 27, 'Efectivo: $ 121800.00<br />');
INSERT INTO `sales` VALUES ('2016-05-31 11:43:48', 15, 1, '0', 28, 'Efectivo: $ 835200.00<br />');
INSERT INTO `sales` VALUES ('2016-05-31 20:10:19', 9, 1, '0', 29, 'Efectivo: $ 40600.00<br />');
INSERT INTO `sales` VALUES ('2016-05-31 20:48:09', 15, 1, '0', 30, 'Efectivo: $ 100000.00<br />');
INSERT INTO `sales` VALUES ('2016-05-31 20:50:48', 22, 1, '0', 31, 'Efectivo: $ 208800.00<br />');
INSERT INTO `sales` VALUES ('2016-06-07 23:33:08', 15, 1, NULL, 32, 'Efectivo: $ 619440.00<br />');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `sales_items`
-- 

CREATE TABLE `sales_items` (
  `sale_id` int(11) NOT NULL default '0',
  `item_id` int(11) NOT NULL default '0',
  `description` varchar(30) collate utf8_unicode_ci default NULL,
  `line` int(3) NOT NULL default '0',
  `quantity_purchased` double(15,2) NOT NULL default '0.00',
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` double(15,2) NOT NULL,
  `discount_percent` int(11) NOT NULL default '0',
  PRIMARY KEY  (`sale_id`,`item_id`,`line`),
  KEY `item_id` (`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Volcar la base de datos para la tabla `sales_items`
-- 

INSERT INTO `sales_items` VALUES (1, 3, 'caneca de pintura por 5 galone', 1, 1.00, 103230.00, 135000.00, 0);
INSERT INTO `sales_items` VALUES (2, 4, '', 1, 6.00, 31000.00, 35000.00, 0);
INSERT INTO `sales_items` VALUES (3, 3, 'caneca de pintura por 5 galone', 2, 2.00, 103230.00, 135000.00, 0);
INSERT INTO `sales_items` VALUES (3, 4, '', 1, 3.00, 31000.00, 35000.00, 0);
INSERT INTO `sales_items` VALUES (4, 4, '', 1, 1.00, 31000.00, 35000.00, 0);
INSERT INTO `sales_items` VALUES (4, 3, 'caneca de pintura por 5 galone', 2, 5.00, 103230.00, 135000.00, 0);
INSERT INTO `sales_items` VALUES (5, 5, 'Esmalte superlavable 5 galones', 1, 5.00, 150000.00, 180000.00, 0);
INSERT INTO `sales_items` VALUES (6, 3, 'caneca de pintura por 5 galone', 1, 3.00, 103230.00, 135000.00, 0);
INSERT INTO `sales_items` VALUES (6, 5, 'Esmalte superlavable 5 galones', 2, 1.00, 150000.00, 180000.00, 0);
INSERT INTO `sales_items` VALUES (7, 5, 'Esmalte superlavable 5 galones', 1, 2.00, 150000.00, 180000.00, 0);
INSERT INTO `sales_items` VALUES (8, 2, '', 1, 3.00, 31000.00, 35000.00, 2);
INSERT INTO `sales_items` VALUES (9, 1, 'caneca de pintura por 5 galone', 1, 3.00, 103230.00, 135000.00, 0);
INSERT INTO `sales_items` VALUES (10, 1, 'caneca de pintura por 5 galone', 1, 3.00, 103230.00, 135000.00, 0);
INSERT INTO `sales_items` VALUES (11, 3, 'Esmalte superlavable 5 galones', 1, 3.00, 150000.00, 180000.00, 0);
INSERT INTO `sales_items` VALUES (11, 2, '', 2, 5.00, 31000.00, 35000.00, 0);
INSERT INTO `sales_items` VALUES (12, 3, 'Esmalte superlavable 5 galones', 1, 5.00, 150000.00, 180000.00, 0);
INSERT INTO `sales_items` VALUES (13, 2, '', 1, 2.00, 31000.00, 35000.00, 0);
INSERT INTO `sales_items` VALUES (14, 3, 'Esmalte superlavable 5 galones', 1, 1.00, 150000.00, 180000.00, 0);
INSERT INTO `sales_items` VALUES (15, 3, 'Esmalte superlavable 5 galones', 1, 3.00, 150000.00, 180000.00, 0);
INSERT INTO `sales_items` VALUES (16, 1, 'caneca de pintura por 5 galone', 1, 1.00, 103230.00, 135000.00, 0);
INSERT INTO `sales_items` VALUES (17, 1, 'caneca de pintura por 5 galone', 1, -1.00, 103230.00, 135000.00, 0);
INSERT INTO `sales_items` VALUES (18, 2, '', 1, 1.00, 31000.00, 35000.00, 0);
INSERT INTO `sales_items` VALUES (19, 2, '', 1, -1.00, 31000.00, 35000.00, 0);
INSERT INTO `sales_items` VALUES (20, 4, 'Pintura Lavable negra', 1, 1.00, 145000.00, 178000.00, 0);
INSERT INTO `sales_items` VALUES (21, 4, 'Pintura Lavable negra', 1, 3.00, 145000.00, 178000.00, 0);
INSERT INTO `sales_items` VALUES (22, 2, '', 1, 1.00, 31000.00, 35000.00, 0);
INSERT INTO `sales_items` VALUES (23, 3, 'Esmalte superlavable 5 galones', 1, 1.00, 150000.00, 180000.00, 0);
INSERT INTO `sales_items` VALUES (23, 2, '', 2, 1.00, 31000.00, 35000.00, 0);
INSERT INTO `sales_items` VALUES (24, 2, '', 1, 4.00, 31000.00, 35000.00, 0);
INSERT INTO `sales_items` VALUES (25, 3, 'Esmalte superlavable 5 galones', 1, 2.00, 150000.00, 180000.00, 0);
INSERT INTO `sales_items` VALUES (26, 3, 'Esmalte superlavable 5 galones', 1, 2.00, 150000.00, 180000.00, 0);
INSERT INTO `sales_items` VALUES (27, 2, '', 1, 3.00, 31000.00, 35000.00, 0);
INSERT INTO `sales_items` VALUES (28, 3, 'Esmalte superlavable 5 galones', 1, 4.00, 150000.00, 180000.00, 0);
INSERT INTO `sales_items` VALUES (29, 2, '', 1, 1.00, 31000.00, 35000.00, 0);
INSERT INTO `sales_items` VALUES (30, 5, '', 1, 2.00, 35000.00, 41000.00, 0);
INSERT INTO `sales_items` VALUES (31, 3, 'Esmalte superlavable 5 galones', 1, 1.00, 150000.00, 180000.00, 0);
INSERT INTO `sales_items` VALUES (32, 4, 'Pintura Lavable negra', 1, 3.00, 145000.00, 178000.00, 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `sales_items_taxes`
-- 

CREATE TABLE `sales_items_taxes` (
  `sale_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `line` int(3) NOT NULL default '0',
  `name` varchar(300) collate utf8_unicode_ci NOT NULL,
  `percent` double(15,2) NOT NULL,
  PRIMARY KEY  (`sale_id`,`item_id`,`line`,`name`,`percent`),
  KEY `item_id` (`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Volcar la base de datos para la tabla `sales_items_taxes`
-- 

INSERT INTO `sales_items_taxes` VALUES (1, 3, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (2, 4, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (3, 3, 2, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (3, 4, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (4, 3, 2, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (4, 4, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (5, 5, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (6, 3, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (6, 5, 2, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (7, 5, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (8, 2, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (9, 1, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (10, 1, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (11, 2, 2, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (11, 3, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (12, 3, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (13, 2, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (14, 3, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (15, 3, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (16, 1, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (17, 1, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (18, 2, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (19, 2, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (20, 4, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (21, 4, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (22, 2, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (23, 2, 2, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (23, 3, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (24, 2, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (25, 3, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (26, 3, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (27, 2, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (28, 3, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (29, 2, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (30, 5, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (31, 3, 1, 'IVA', 16.00);
INSERT INTO `sales_items_taxes` VALUES (32, 4, 1, 'IVA', 16.00);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `sales_payments`
-- 

CREATE TABLE `sales_payments` (
  `sale_id` int(11) NOT NULL,
  `payment_type` varchar(40) collate utf8_unicode_ci NOT NULL,
  `payment_amount` decimal(15,2) NOT NULL,
  PRIMARY KEY  (`sale_id`,`payment_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Volcar la base de datos para la tabla `sales_payments`
-- 

INSERT INTO `sales_payments` VALUES (1, 'Efectivo', 156600.00);
INSERT INTO `sales_payments` VALUES (2, 'Cheque', 243600.00);
INSERT INTO `sales_payments` VALUES (3, 'Tarjeta de DÃ©bito', 435000.00);
INSERT INTO `sales_payments` VALUES (4, 'Tarjeta de DÃ©bito', 823600.00);
INSERT INTO `sales_payments` VALUES (5, 'Efectivo', 1044000.00);
INSERT INTO `sales_payments` VALUES (6, 'Tarjeta de DÃ©bito', 678600.00);
INSERT INTO `sales_payments` VALUES (7, 'Efectivo', 417600.00);
INSERT INTO `sales_payments` VALUES (8, 'Efectivo', 119364.00);
INSERT INTO `sales_payments` VALUES (9, 'Efectivo', 469800.00);
INSERT INTO `sales_payments` VALUES (10, 'Efectivo', 469800.00);
INSERT INTO `sales_payments` VALUES (11, 'Tarjeta de Débito', 829400.00);
INSERT INTO `sales_payments` VALUES (12, 'Efectivo', 1044000.00);
INSERT INTO `sales_payments` VALUES (13, 'Efectivo', 81200.00);
INSERT INTO `sales_payments` VALUES (14, 'Efectivo', 208800.00);
INSERT INTO `sales_payments` VALUES (15, 'Efectivo', 626400.00);
INSERT INTO `sales_payments` VALUES (16, 'Efectivo', 156600.00);
INSERT INTO `sales_payments` VALUES (17, 'Efectivo', -156600.00);
INSERT INTO `sales_payments` VALUES (18, 'Efectivo', 40600.00);
INSERT INTO `sales_payments` VALUES (19, 'Efectivo', -40600.00);
INSERT INTO `sales_payments` VALUES (20, 'Efectivo', 100000.00);
INSERT INTO `sales_payments` VALUES (20, 'Tarjeta de Débito', 106480.00);
INSERT INTO `sales_payments` VALUES (21, 'Efectivo', 619440.00);
INSERT INTO `sales_payments` VALUES (22, 'Efectivo', 40600.00);
INSERT INTO `sales_payments` VALUES (23, 'Efectivo', 249400.00);
INSERT INTO `sales_payments` VALUES (24, 'Tarjeta de Débito', 100000.00);
INSERT INTO `sales_payments` VALUES (24, 'Efectivo', 62400.00);
INSERT INTO `sales_payments` VALUES (25, 'Efectivo', 417600.00);
INSERT INTO `sales_payments` VALUES (26, 'Efectivo', 417600.00);
INSERT INTO `sales_payments` VALUES (27, 'Efectivo', 121800.00);
INSERT INTO `sales_payments` VALUES (28, 'Efectivo', 835200.00);
INSERT INTO `sales_payments` VALUES (29, 'Efectivo', 40600.00);
INSERT INTO `sales_payments` VALUES (30, 'Efectivo', 100000.00);
INSERT INTO `sales_payments` VALUES (31, 'Efectivo', 208800.00);
INSERT INTO `sales_payments` VALUES (32, 'Efectivo', 619440.00);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `sessions`
-- 

CREATE TABLE `sessions` (
  `id` varchar(40) collate utf8_unicode_ci NOT NULL default '0',
  `ip_address` varchar(16) collate utf8_unicode_ci NOT NULL default '0',
  `timestamp` int(11) unsigned NOT NULL default '0',
  `data` blob,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Volcar la base de datos para la tabla `sessions`
-- 

INSERT INTO `sessions` VALUES ('f1b09390fca405725455c6c6d9ccfbca7598206d', '127.0.0.1', 1465358851, 0x5f5f63695f6c6173745f726567656e65726174657c693a313436353335383835313b);
INSERT INTO `sessions` VALUES ('cf114aac5a3e7d828a128a3467f42544b61cfa81', '127.0.0.1', 1465359219, 0x5f5f63695f6c6173745f726567656e65726174657c693a313436353335393231393b);
INSERT INTO `sessions` VALUES ('649110499872094c3742dfc3fe8422650fde8b83', '127.0.0.1', 1465360388, 0x5f5f63695f6c6173745f726567656e65726174657c693a313436353336303132363b706572736f6e5f69647c733a313a2231223b);
INSERT INTO `sessions` VALUES ('7c995b105ba27b271a288220f58eb30ab989d3f4', '127.0.0.1', 1465361859, 0x5f5f63695f6c6173745f726567656e65726174657c693a313436353336313835393b706572736f6e5f69647c733a313a2231223b);
INSERT INTO `sessions` VALUES ('1cc13f824382868663f298acb09166d049f4eebb', '127.0.0.1', 1465360722, 0x5f5f63695f6c6173745f726567656e65726174657c693a313436353336303534353b706572736f6e5f69647c733a313a2231223b);
INSERT INTO `sessions` VALUES ('07ed2b0374602dcc270f8a42c1e460571546d5d7', '127.0.0.1', 1465361070, 0x5f5f63695f6c6173745f726567656e65726174657c693a313436353336303930373b706572736f6e5f69647c733a313a2231223b);
INSERT INTO `sessions` VALUES ('91bab06039aa8aa12f18e8720c9336d3761f4bd4', '127.0.0.1', 1465361834, 0x5f5f63695f6c6173745f726567656e65726174657c693a313436353336313534343b706572736f6e5f69647c733a313a2231223b);
INSERT INTO `sessions` VALUES ('04e434ecb32b00dc36e173c49e4925f16d7719f8', '127.0.0.1', 1465362439, 0x5f5f63695f6c6173745f726567656e65726174657c693a313436353336323239333b706572736f6e5f69647c733a313a2231223b726563765f6d6f64657c733a373a2272656365697665223b);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `suppliers`
-- 

CREATE TABLE `suppliers` (
  `person_id` int(11) NOT NULL,
  `company_name` varchar(300) collate utf8_unicode_ci NOT NULL,
  `account_number` varchar(300) collate utf8_unicode_ci default NULL,
  `deleted` int(1) NOT NULL default '0',
  UNIQUE KEY `account_number` (`account_number`),
  KEY `person_id` (`person_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Volcar la base de datos para la tabla `suppliers`
-- 

INSERT INTO `suppliers` VALUES (4, 'Exportaciones e Importaciones S.A.C', '3987456123', 0);
INSERT INTO `suppliers` VALUES (11, 'Pintuco S.A.', NULL, 0);
INSERT INTO `suppliers` VALUES (12, 'Pinturas Duitama', NULL, 0);
INSERT INTO `suppliers` VALUES (18, 'Pinturas Fernandez', NULL, 0);
INSERT INTO `suppliers` VALUES (28, 'zgsdg', NULL, 0);
INSERT INTO `suppliers` VALUES (29, 'dcghfrdjh', NULL, 0);
INSERT INTO `suppliers` VALUES (30, 'dsavdszb', NULL, 0);
INSERT INTO `suppliers` VALUES (31, 'sgrhrdhrh', NULL, 0);
INSERT INTO `suppliers` VALUES (32, 'awfdsafwg', NULL, 0);
INSERT INTO `suppliers` VALUES (39, 'gvszgzsg', NULL, 0);
